import { motion, useScroll, useTransform } from "framer-motion";
import { useRef } from "react";
import { Button } from "../components/ui/button";
import { Github, Linkedin } from "lucide-react";

export default function Home() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "20%"]);

  return (
    <main className="min-h-screen bg-gradient-to-br from-[#0f172a] to-[#1e293b] text-white font-sans">
      <section ref={heroRef} className="h-screen flex flex-col justify-center items-center text-center px-4">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          style={{ y }}
          className="text-4xl md:text-6xl font-bold mb-4"
        >
          Hi, I’m Ali Asad Hassan
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 1 }}
          className="text-lg md:text-2xl max-w-2xl text-gray-300"
        >
          Senior .NET Developer | Big Data Engineer | Cloud Enthusiast
        </motion.p>
        <motion.div
          className="mt-8 flex gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 1 }}
        >
          <Button variant="default">Download CV</Button>
          <Button variant="outline">Let’s Connect</Button>
        </motion.div>
      </section>
      <section className="py-20 px-6 md:px-20 bg-white text-gray-900">
        <h2 className="text-3xl font-bold text-center mb-12">About Me</h2>
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-3xl mx-auto text-lg leading-relaxed"
        >
          I’m a passionate software engineer with 8+ years of experience specializing in building scalable enterprise applications using .NET technologies, cloud platforms like Azure, and data platforms such as Databricks and Snowflake. My goal is to bridge the gap between complex data systems and meaningful business outcomes.
        </motion.p>
      </section>
      <section className="py-20 px-6 md:px-20 bg-gray-100 text-gray-900">
        <h2 className="text-3xl font-bold text-center mb-12">Skills</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto text-center">
          {[".NET Core", "Azure", "Snowflake", "Databricks", "SQL", "Git & GitHub", "React.js", "CI/CD"].map((skill, index) => (
            <motion.div
              key={skill}
              className="bg-white p-4 rounded shadow hover:scale-105 transition-transform"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              {skill}
            </motion.div>
          ))}
        </div>
      </section>
      <section className="py-20 px-6 md:px-20 bg-white text-gray-900">
        <h2 className="text-3xl font-bold text-center mb-12">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {[{
            title: "Azure Feed Pipeline Debugger",
            desc: "Designed a robust solution to trace, validate, and debug Azure data feeds from landing to archive folders."
          }, {
            title: "Snowflake Migration Engine",
            desc: "Led migration of 1TB+ data from Azure Databricks to Snowflake, improving performance by 30%."
          }, {
            title: "GitHub Connected Notebook Runner",
            desc: "Integrated Databricks with GitHub for CI/CD notebook versioning using API and secret-based workflows."
          }].map((project, i) => (
            <motion.div
              key={i}
              className="p-6 border rounded-xl shadow-md bg-white hover:shadow-xl hover:scale-[1.02] transition-transform"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
              <p className="text-gray-700">{project.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
      <section className="py-20 px-6 md:px-20 bg-gray-100 text-gray-900">
        <h2 className="text-3xl font-bold text-center mb-12">Experience</h2>
        <div className="max-w-4xl mx-auto space-y-8">
          {[{
            title: "Algomus – Senior Software Engineer",
            time: "2023 – Present",
            desc: "Working on enterprise data solutions, Azure-based feed pipelines, and Snowflake optimizations."
          }, {
            title: "Magnatec Systems – Senior Software Engineer",
            time: "2016 – 2023",
            desc: "Built .NET-based applications, RESTful APIs, SQL Server solutions, and frontend features using Bootstrap and jQuery."
          }].map((exp, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-semibold">{exp.title}</h3>
              <p className="text-gray-700">{exp.time}</p>
              <p className="text-gray-600 mt-2">{exp.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>
      <section className="py-20 px-6 md:px-20 bg-white text-gray-900">
        <h2 className="text-3xl font-bold text-center mb-12">Contact Me</h2>
        <motion.div
          className="flex justify-center gap-6 text-blue-600"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 1 }}
          viewport={{ once: true }}
        >
          <a href="https://github.com/aliasad47" target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform">
            <Github size={32} />
          </a>
          <a href="https://linkedin.com/in/aliasad47" target="_blank" rel="noopener noreferrer" className="hover:scale-110 transition-transform">
            <Linkedin size={32} />
          </a>
          <a href="mailto:ali@example.com" className="hover:scale-110 transition-transform">
            <Button variant="link">ali@example.com</Button>
          </a>
        </motion.div>
      </section>
      <footer className="text-center py-10 text-gray-400 text-sm">
        © 2025 Ali Asad Hassan. Built with 💻 React + Tailwind.
      </footer>
    </main>
  );
}